#include <iostream>
#include "UFSet.h"

using namespace std;

bool empiezaConMismaLetra(Equipo e1, Equipo e2)
{
    return nombreEquipo(e1).at(0) == nombreEquipo(e2).at(0);
}

void imprimirUFSets(UFSet* ufSets, int cantidad)
{
    cout << "UFSets {" << endl;
    for(int i = 0; i < cantidad; i++)
    {
        cout << "  " << nombreEquipo(elemUFS(ufSets[i])) << " -> " << nombreEquipo(elemUFS(findUFS(ufSets[i]))) << endl;
    }
    cout << "}" << endl << endl;
}

/** Prop: Realiza la union entre el UFSet dado por parametro con todos los UFSet que tengan
          la misma primer letra en el equipo.
    Costo: O(n).
    Prec: No hay.
  */
void unirConEquiposDeMismaPrimerLetra(UFSet ufs, UFSet* singletons){
    for(int i = 0; i<20; i++){
        if(empiezaConMismaLetra(elemUFS(ufs),elemUFS(singletons[i])))
            unionUFS(ufs,singletons[i]);
    }
}

void test_defensa()
{
    int cantidadequipos = 20;

    Equipo* equipos = new Equipo[cantidadequipos];

    // con a
    equipos[0]  = crearEquipoConNombre("Aldosivi");
    equipos[1]  = crearEquipoConNombre("Atletico madrid");
    equipos[2]  = crearEquipoConNombre("Arsenal");
    equipos[3]  = crearEquipoConNombre("America de cali");

    // con b
    equipos[4]  = crearEquipoConNombre("Boca");
    equipos[5]  = crearEquipoConNombre("Banfield");

    // con f
    equipos[6]  = crearEquipoConNombre("Ferro");

    // con m
    equipos[7]  = crearEquipoConNombre("Manchester United");
    equipos[8]  = crearEquipoConNombre("Mallorca");
    equipos[9]  = crearEquipoConNombre("Malaga");
    equipos[10] = crearEquipoConNombre("Manchester City");

    // con p
    equipos[11] = crearEquipoConNombre("Paris Saint-Germain");
    equipos[12] = crearEquipoConNombre("Palermo");
    equipos[13] = crearEquipoConNombre("Palmeiras");

    // con r
    equipos[14] = crearEquipoConNombre("River");
    equipos[15] = crearEquipoConNombre("Rosario Central");
    equipos[16] = crearEquipoConNombre("Racing");
    equipos[17] = crearEquipoConNombre("Real Madrid");
    equipos[18] = crearEquipoConNombre("Rayo Vallecano");
    equipos[19] = crearEquipoConNombre("Real Sociedad");

    // Primero se crean los singletons para cada elemento
    UFSet* singletons = new UFSet[cantidadequipos];

    for(int i = 0; i<20; i++)
        singletons[i] = createUFS(equipos[i]);


    cout << "Los singletons se crean correctamente: " << endl;
    imprimirUFSets(singletons, cantidadequipos);

    // Se recorren todas las combinaciones uniendo solo los equipos
    // cuyo nombre empieza con la misma letra
    ///Costo = O(n^²)
    for(int i = 0; i<20; i++){
        unirConEquiposDeMismaPrimerLetra(singletons[i],singletons); ///O(n).
    }

    cout << "Los elementos fueron agrupados correctamente: " << endl;
    imprimirUFSets(singletons, cantidadequipos);

    // Se libera la memoria de los nodos

    for(int i = 0; i<20; i++)
        destroyUFS(singletons[i]);

    // Se libera el resto de la memoria
    delete[] equipos;
    delete[] singletons;
}

int main()
{
    test_defensa();

    return 0;
}
