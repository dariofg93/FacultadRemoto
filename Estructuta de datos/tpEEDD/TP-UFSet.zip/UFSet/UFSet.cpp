#include "UFSet.h"

/*
 * UFSet.cpp contiene la implementacion de la interfaz para
 * UFSet declarada en UFSet.h. Los estudientes deberan
 * imlementar las operaciones de acuerdo a la representacion
 * elegida para el tipo UFSet.
 */

/* El tipo UFNode* representa:
*  1. un elemento de un UFSet (o sea, un nodo del
*     arbol que contiene a todos los elementos del conjunto)
*  2. al conjunto en su totalidad, si el nodo es la raiz
*     del arbol
*
*  El nodo tiene un puntero a su elemento asociado en el
*  campo element. Los estudiantes deberan agregar los
*  campos necesarios para completar la representacion.
*/
struct UFNode
{
   ELEM_TYPE element;
   // COMPLETAR EL RESTO
};

/* Inicializa el UFSet ufset, cuyo valor asociado sera value */
UFSet createUFS(ELEM_TYPE value)
{
  // COMPLETAR
}

ELEM_TYPE elemUFS(UFSet ufset)
{
  // COMPLETAR
}

/*
 * Encuentra el elemento distinguido para el UFSet dado. Esta
 * operacion puede ser optimizada con la tecnica de compresion
 * de camino.
 */
UFSet findUFS(UFSet& elem)
{
  // COMPLETAR
}

/*
 * Calcula la union entre los conjuntos ufset1 y ufset2. Esta
 * operacion puede ser optimizada con la tecnica de union por
 * rango.
 */
void unionUFS(UFSet& ufset1, UFSet& ufset2)
{
  // COMPLETAR
}


/*
 * Borra la memoria de un elemento
 */
void destroyUFS(UFSet& ufset)
{
  // COMPLETAR
}


