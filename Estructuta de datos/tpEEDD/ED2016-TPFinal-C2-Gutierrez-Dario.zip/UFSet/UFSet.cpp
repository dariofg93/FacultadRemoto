#include "UFSet.h"

/*
 * UFSet.cpp contiene la implementacion de la interfaz para
 * UFSet declarada en UFSet.h. Los estudientes deberan
 * imlementar las operaciones de acuerdo a la representacion
 * elegida para el tipo UFSet.
 */

/* El tipo UFNode* representa:
*  1. un elemento de un UFSet (o sea, un nodo del
*     arbol que contiene a todos los elementos del conjunto)
*  2. al conjunto en su totalidad, si el nodo es la raiz
*     del arbol
*
*  El nodo tiene un puntero a su elemento asociado en el
*  campo element. Los estudiantes deberan agregar los
*  campos necesarios para completar la representacion.
*/
struct UFNode
{
   ELEM_TYPE element;       ///Conserva el ELEM_TYPE.
   UFNode* father;          ///Contiene el siguiente nodo del "grupo", que puede ser el representante o no.
   int rango;               ///El rango solamente es verdaderamente útil cuando se
                            ///lo pide desde el UFNode* representante del "grupo".
};

/**
    INV. REPRESENTACION:
        * El father puede ser el representante del grupo x, NUNCA es NULL.
        * rango >= 0.
*/

/** Aclarion: */
    //Documentacion provista por el docente.
    ///Documentacion provista por el alumno.


/* Inicializa el UFSet ufset, cuyo valor asociado sera value */
/** Prec: No hay */
UFSet createUFS(ELEM_TYPE value)
{
    UFNode* newUFS = new UFNode;
    newUFS->element = value;
    newUFS->father = newUFS;
    newUFS->rango = 0;

    return newUFS;
}

/** Retorna el ELEM_TYPE del UFSet dado por parámetro.
  * Prec: No hay.
  */
ELEM_TYPE elemUFS(UFSet ufset)
{
    return ufset->element;
}

/** Asigna el representante(segundo elemento dado)
  * al UFSet (primer elemento dado) y lo devuelve.
  * Prec: No hay.
  */
UFSet asignarRepYretornar(UFSet& elem,UFSet found){
    elem->father = found;
    return found;
}

/*
 * Encuentra el elemento distinguido para el UFSet dado. Esta
 * operacion puede ser optimizada con la tecnica de compresion
 * de camino.
 */
 /** Obs: Al tener la informacion extra de que el caso de la Copa
   * América es trivial, se prefiere una solución recursiva a una
   * iterativa, para tener mayor legibilidad del codigo.
   * Prec: No hay.
   */
UFSet findUFS(UFSet& elem)
{
    if(elem->father != elem)
        return asignarRepYretornar(elem,findUFS(elem->father));
    else{
        return elem;
    }
}

/** Retorna el rango del UFSet dado.
  * Prec: No hay.
  */
int ranking(UFSet ufs){
    return ufs->rango;
}

/**
  * Une Dos UFSet dependiendo del mejor caso(Mayor rango = representante).
  * Obs: No contempla el caso en el que ambos tengan el mismo rango.
  * Prec: No hay.
  */
void agregarAlMayorRango(UFSet& ufs1, UFSet& ufs2){

    if(ranking(ufs1) > ranking(ufs2))
        ufs2->father = ufs1;
    else
        ufs1->father = ufs2;
}

/*
 * Calcula la union entre los conjuntos ufset1 y ufset2. Esta
 * operacion puede ser optimizada con la tecnica de union por
 * rango.
 */
/** Prec: No hay. */
void unionUFS(UFSet& ufset1, UFSet& ufset2)
{
    UFNode* ufs1 = findUFS(ufset1);         ///Se guarda el representante de ambos UFSet
    UFNode* ufs2 = findUFS(ufset2);         ///para hacer una sola busqueda.

    if(ranking(ufs1)==ranking(ufs1)){       ///Unico caso en el que el rango aumenta en 1.
        ufs2->father = ufs1;
        ufs1->rango++;
    }else
        agregarAlMayorRango(ufs1,ufs2);
}

/*
 * Borra la memoria de un elemento
 */
 /** Prec: No hay. */
void destroyUFS(UFSet& ufset)
{
    delete ufset;
    ufset = NULL;
}
