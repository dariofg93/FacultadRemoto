#ifndef _TEST_H
#define _TEST_H

#include <iostream>
#include <vector>
#include "UFSet.h"
#include "Equipo.h"

using namespace std;

void test(string titulo, vector<Equipo> equipos);

#endif
