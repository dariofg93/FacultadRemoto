Pharo 4.0

This distribution was built December 07, 2015.