#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>

extern void monocromatizarMax (unsigned* red, unsigned* green, unsigned* blue, unsigned int tam, unsigned* resultado);



void help() {
    printf("Parametros:\n");
    printf("--help            (-h) Muestra esta ayuda\n");
    printf("--input           (-i) Nombre de archivo de entrada ");
    printf(" (obligatorio)\n");
    printf("--output          (-o) Nombre de archivo de salida ");
    printf(" (obligatorio)\n");
}


int main(int argc, char **argv) {
   

    const char* const op_cortas = "hi:o:" ; // posibles parametros, van con -
    int siguiente_opcion;

    // forma larga para las opciones. En consola van con --
    const struct option op_largas[] = {
                                          {"input",       1, NULL,  'i'},
                                          {"output",      1, NULL,  'o'},
                                          {"help",        0, NULL,  'h'},
                                          { NULL,         0, NULL,   0 }
                                      };

    // si no puso parametros, le decimos que necesitamos el archivo
    if (argc == 1) {
        printf("\nERROR: No se especifico una imagen!\n\n");
        help();
        return 1;
    }

    // declaracion de variables
    char* ficheroEntrada = NULL;      // nombre del archivo
    char* ficheroSalida = NULL;

    while (1) {
        // llamamos a la función getopt
        siguiente_opcion = getopt_long (argc, argv, op_cortas, op_largas, NULL);

        if (siguiente_opcion == -1) // no hay mas opciones
            break;

        // para cada parametro, seteamos el flag correspondiente
        switch (siguiente_opcion) {

        case 'i' : /* -i ó --input */
            ficheroEntrada = optarg; /* optarg contiene el argumento de -i */
            break;
        case 'o' : /* -o ó --output */
            ficheroSalida = optarg; /* optarg contiene el argumento de -o*/
            break;

        case 'h' : /* -h ó --help */
            help();
            return 0;

        case -1 : /* No hay más opciones */
            break;

        default : /* Algo más? No esperado. Abortamos */
            printf("Formato de opciones invalido!\n");
            help();
            return 1;
        }
    }


    // Para umbralizar se necesitan 2 parametros. Como getOpt solo toma uno, el otro lo coloca en
    // los no identificados. Para evitar que se ponga mas de uno, pedimos que solo haya un parametro no
    // identificado.

    // abrimos el archivo
    FILE* fichero;
    FILE* salida;
    size_t fread_res;
    unsigned int ancho, alto, offset;
    char marca1, marca2;
    if (ficheroSalida == NULL) {
        printf("\nERROR: No se pudo crear el archivo de salida!\n\n");
        return 1;
    }
    fichero = fopen(ficheroEntrada, "rbw+");
    salida = fopen(ficheroSalida, "wb");
    if (fichero == NULL) {
        printf("\nERROR: Archivo no encontrado! Ingreso el nombre correcto?\n\n");
        help();
        return 1;
    }
    if (salida == NULL) {
        printf("\nERROR: No se pudo crear el archivo de salida!\n\n");
        return 1;
    } else {
        marca1 = fgetc(fichero);  // leemos los dos primeros bytes
        marca2 = fgetc(fichero);
        if (marca1 =='B' && marca2 =='M') {     // si son BM, sino paramos

            fseek(fichero, 18, SEEK_SET);       // posicion 18: ancho
            fread_res = fread(&ancho, 1, 4, fichero);
            fread_res = fread(&alto, 1, 4, fichero);        // siguiente dato: alto
            fseek(fichero, 10, SEEK_SET);       // tomamos el offset hasta los pixeles
            fread_res = fread(&offset,1,4,fichero);
            
            short int sumandoextra = (4 - (ancho*3 % 4)) % 4;
            unsigned* azul = malloc(sizeof(unsigned)*ancho*alto);
            unsigned* rojo = malloc(sizeof(unsigned)*ancho*alto);
            unsigned* verde = malloc(sizeof(unsigned)*ancho*alto);
            unsigned* matriz = malloc(sizeof(unsigned)*ancho*alto);
            int j = 0;
            fseek(fichero, offset, SEEK_SET);

            // leemos la imagen a memoria en 3 matrices separadas
            // que corresponden a los canales rojo, verde y azul
            // para facilitar el procesamiento posterior
            while(j < alto) {
                int i = 0;
                while(i < ancho) {
                    unsigned char aux_char;
                    fread_res = fread(&aux_char,1,1,fichero);
                    rojo[j*ancho+i] = aux_char;
                    fread_res = fread(&aux_char,1,1,fichero);
                    verde[j*ancho+i] = aux_char;
                    fread_res = fread(&aux_char,1,1,fichero);
                    azul[j*ancho+i] = aux_char;
                    i++;
                }
                fseek(fichero,sumandoextra, SEEK_CUR);
                j++;
            }

            printf("Monocromatizando...\n");
            monocromatizarMax(rojo, verde, azul, ancho*alto, matriz);

 
            free(azul);
            free(rojo);
            free(verde);

            // guardo la matriz en el archivo de salida
            int i = 0;
            char * info = (char*) malloc(offset);
            fseek(fichero, 0, SEEK_SET);
            fread_res = fread(info,offset,1,fichero);
            fwrite(info, offset, 1, salida);
            fseek(salida, offset, SEEK_SET);
            char* ceros = (char*) malloc(sumandoextra);
            i = 0;
            while(i < sumandoextra) {
                ceros[i] = 0;
                i++;
            }
            i = 0;
            while(i < alto) {
                int j = 0;
                while(j < ancho) {
                    char aux_char = matriz[i*ancho+j];
                    fwrite(&aux_char, 1, 1, salida);
                    fwrite(&aux_char, 1, 1, salida);
                    fwrite(&aux_char, 1, 1, salida);

                    j++;
                }
                fwrite(ceros, sumandoextra, 1, salida);
                i++;
            }
            // limpieza
            free(ceros);
            free(info);
            free(matriz);
            fclose(fichero);
            fclose(salida);
        }
    }
    return 0;
}

