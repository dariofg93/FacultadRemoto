package modeloRegistroYequipamiento;

import org.junit.Test;

public class BaseTest {		//Test creado solo para tener mas Cobertura del codigo

	@Test
	public void test() {
		@SuppressWarnings("unused")
		Equipamiento fullTest = new Base();
	}
}
