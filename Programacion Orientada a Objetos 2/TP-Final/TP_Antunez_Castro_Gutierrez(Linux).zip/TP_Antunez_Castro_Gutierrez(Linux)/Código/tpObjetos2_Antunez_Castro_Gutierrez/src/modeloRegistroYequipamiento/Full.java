package modeloRegistroYequipamiento;

public class Full extends Equipamiento{

}
