package modeloRegistroYequipamiento;

public class Base extends Equipamiento{

}
