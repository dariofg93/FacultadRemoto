# TpObjetos2
Aca tienen el Tp de Objetos :D

Link de los UML: -Tp final Concesionaria:   https://www.draw.io/#G0ByyLjI7nzSVabVhjcEpPdGVGQnc
               ///// -AlternativaConcesionaria: https://www.draw.io/#G0B0ePwLHYzSq3eFUxS2pRbjBVb1k
Para acceder a ambos, se debe tener una invitacion en alguna de las cuentas utilizadas.
