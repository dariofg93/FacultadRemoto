package expresionesLogicas;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class AndTest {

	private And evaluaATrue;
	private And evaluaAFalse1;
	private And evaluaAFalse2;
	private And evaluaAFalse3;
	private And andCompuesto;
	
	@Before
	public void setUp(){
		this.evaluaATrue = new And((new ValorBooleano(true)),(new ValorBooleano(true)));
		this.evaluaAFalse1 = new And((new ValorBooleano(false)),(new ValorBooleano(true)));
		this.evaluaAFalse2 = new And((new ValorBooleano(true)),(new ValorBooleano(false)));
		this.evaluaAFalse3 = new And((new ValorBooleano(false)),(new ValorBooleano(false)));
		this.andCompuesto = new And (evaluaAFalse3, evaluaAFalse2);
	}
	
	@Test
	public void testCalcularValor() {
		assertTrue(evaluaATrue.calcularValor());
		assertFalse(evaluaAFalse1.calcularValor());
		assertFalse(evaluaAFalse2.calcularValor());
		assertFalse(evaluaAFalse3.calcularValor());
		assertFalse(andCompuesto.calcularValor());
	}

}
