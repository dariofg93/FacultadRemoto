package expresionesLogicas;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ValorBooleanoTest {

	private ValorBooleano valorTrue;
	private ValorBooleano valorFalse;
	
	@Before
	public void setUp(){
		this.valorFalse = new ValorBooleano(false);
		this.valorTrue = new ValorBooleano(true);
	}
	
	@Test
	public void testCalcularValor() {
		assertTrue(valorTrue.calcularValor());
		assertFalse(valorFalse.calcularValor());
	}

}
