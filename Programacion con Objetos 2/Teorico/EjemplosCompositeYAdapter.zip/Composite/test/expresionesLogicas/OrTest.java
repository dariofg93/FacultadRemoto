package expresionesLogicas;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class OrTest {

	private Or evaluaATrue1;
	private Or evaluaAFalse;
	private Or evaluaATrue2;
	private Or evaluaATrue3;
	private Or orCompuesto;
	
	@Before
	public void setUp(){
		this.evaluaATrue1 = new Or((new ValorBooleano(true)),(new ValorBooleano(true)));
		this.evaluaATrue2 = new Or((new ValorBooleano(false)),(new ValorBooleano(true)));
		this.evaluaATrue3 = new Or((new ValorBooleano(true)),(new ValorBooleano(false)));
		this.evaluaAFalse = new Or((new ValorBooleano(false)),(new ValorBooleano(false)));
		this.orCompuesto = new Or (evaluaATrue3, evaluaAFalse);
	}
	
	@Test
	public void testCalcularValor() {
		assertTrue(evaluaATrue1.calcularValor());
		assertTrue(evaluaATrue2.calcularValor());
		assertTrue(evaluaATrue3.calcularValor());
		assertFalse(evaluaAFalse.calcularValor());
		assertTrue(orCompuesto.calcularValor());
	}

}
