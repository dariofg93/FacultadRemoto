package expresionesLogicas;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ExpresionCompuestaTest {

	private Or orEvaluaATrue1;
	private Or orEvaluaAFalse;
	private Or orEvaluaATrue2;
	
	private And andEvaluaATrue;
	private And andEvaluaAFalse2;
	private And andEvaluaAFalse3;
	
	private Or orCompuesto1;
	private And andCompuesto1;
	private Or orCompuesto2;
	private And andCompuesto2;
	
	private And andCompuestoPorOr;
	private Or orCompuestoPorAnd;
	
	private And andMuyCompuesto;
	private Or orMuyCompuesto;
	
	
	@Before
	public void setUp(){
		this.orEvaluaATrue1 = new Or((new ValorBooleano(true)),(new ValorBooleano(true)));
		this.orEvaluaATrue2 = new Or((new ValorBooleano(false)),(new ValorBooleano(true)));
		this.orEvaluaAFalse = new Or((new ValorBooleano(false)),(new ValorBooleano(false)));
		
		this.orCompuesto1 = new Or (this.orEvaluaAFalse, this.orEvaluaAFalse);
		this.orCompuesto2 = new Or (this.orEvaluaATrue1, this.orEvaluaATrue2);
		
		this.andCompuestoPorOr = new And(this.orCompuesto1, this.orCompuesto2);
		
		this.andEvaluaATrue = new And((new ValorBooleano(true)),(new ValorBooleano(true)));
		this.andEvaluaAFalse2 = new And((new ValorBooleano(true)),(new ValorBooleano(false)));
		this.andEvaluaAFalse3 = new And((new ValorBooleano(false)),(new ValorBooleano(false)));
		
		this.andCompuesto1 = new And (this.andEvaluaAFalse3, this.andEvaluaAFalse2);
		this.andCompuesto2 = new And (this.andEvaluaATrue, this.andEvaluaATrue);
		
		this.orCompuestoPorAnd = new Or(this.andCompuesto1, this.andCompuesto2);
		
		this.orMuyCompuesto = new Or(this.orCompuestoPorAnd, this.andCompuestoPorOr);
		this.andMuyCompuesto = new And(this.orCompuestoPorAnd, this.andCompuestoPorOr);
	}
	
	@Test
	public void testCalcularValor() {
		assertFalse(orCompuesto1.calcularValor());
		assertTrue(orCompuesto2.calcularValor());
		
		assertFalse(andCompuesto1.calcularValor());
		assertTrue(andCompuesto2.calcularValor());
		
		assertFalse(andCompuestoPorOr.calcularValor());
		assertTrue(orCompuestoPorAnd.calcularValor());
		
		assertFalse(andMuyCompuesto.calcularValor());
		assertTrue(orMuyCompuesto.calcularValor());
	}

}
