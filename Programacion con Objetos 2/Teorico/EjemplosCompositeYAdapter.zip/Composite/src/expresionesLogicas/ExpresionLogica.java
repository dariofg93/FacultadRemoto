package expresionesLogicas;

public abstract class ExpresionLogica {

	public abstract Boolean calcularValor();
}
