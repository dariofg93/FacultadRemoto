package expresionesLogicas;

public class And extends OperacionLogica{

	public And(ExpresionLogica expresionIzquierda,	ExpresionLogica expresionDerecha) {
		super(expresionIzquierda, expresionDerecha);
	}

	@Override
	public Boolean calcularValor() {
		return  this.getExpresionIzquierda().calcularValor()
				&&
				this.getExpresionDerecha().calcularValor();
	}

	
}
