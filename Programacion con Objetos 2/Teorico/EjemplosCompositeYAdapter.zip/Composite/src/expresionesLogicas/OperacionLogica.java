package expresionesLogicas;

public abstract class OperacionLogica extends ExpresionLogica{

	private ExpresionLogica expresionIzquierda;
	private ExpresionLogica expresionDerecha;
	
	public OperacionLogica(ExpresionLogica expresionIzquierda, ExpresionLogica expresionDerecha) {
		this.setExpresionIzquierda(expresionIzquierda);
		this.setExpresionDerecha(expresionDerecha);
	}
	public ExpresionLogica getExpresionIzquierda() {
		return expresionIzquierda;
	}
	public void setExpresionIzquierda(ExpresionLogica expresionIzquierda) {
		this.expresionIzquierda = expresionIzquierda;
	}
	public ExpresionLogica getExpresionDerecha() {
		return expresionDerecha;
	}
	public void setExpresionDerecha(ExpresionLogica expresionDerecha) {
		this.expresionDerecha = expresionDerecha;
	}
}
