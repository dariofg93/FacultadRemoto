package expresionesLogicas;

public class ValorBooleano extends ExpresionLogica{

	private Boolean valor;

	public ValorBooleano(Boolean valor) {
		this.setValor(valor);
	}
	
	@Override
	public Boolean calcularValor() {
		return this.getValor();
	}

	public Boolean getValor() {
		return valor;
	}

	public void setValor(Boolean valor) {
		this.valor = valor;
	}
	
}
