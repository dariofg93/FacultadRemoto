package expresionesLogicas;

public class Or extends OperacionLogica{

	public Or(ExpresionLogica expresionIzquierda,ExpresionLogica expresionDerecha) {
		super(expresionIzquierda, expresionDerecha);
	}

	@Override
	public Boolean calcularValor() {
		return  this.getExpresionIzquierda().calcularValor()
				||
				this.getExpresionDerecha().calcularValor();
	}

}
