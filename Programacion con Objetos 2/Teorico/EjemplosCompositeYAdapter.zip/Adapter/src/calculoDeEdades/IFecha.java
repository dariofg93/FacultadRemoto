package calculoDeEdades;

public interface IFecha {

	public Integer getDia();
	public Integer getMes();
	public Integer getAnio();
	public IFecha getDiaDeHoy();
	public Integer restarEnAniosA(IFecha fecha);
}
