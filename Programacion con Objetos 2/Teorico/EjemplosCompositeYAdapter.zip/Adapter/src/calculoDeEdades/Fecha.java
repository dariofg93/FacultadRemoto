package calculoDeEdades;

import java.util.GregorianCalendar;

public class Fecha implements IFecha {

	private Integer dia;
	private Integer mes;
	private Integer anio;
	
	public Fecha (Integer dia, Integer mes, Integer anio){
		this.anio=anio;
		this.dia=dia;
		this.mes=mes;
	}
	public Fecha() {
		this(   (new GregorianCalendar()).get(GregorianCalendar.DAY_OF_MONTH),
				(new GregorianCalendar()).get(GregorianCalendar.MONTH)+1,
				(new GregorianCalendar()).get(GregorianCalendar.YEAR)
			);
	}
	@Override
	public Integer getDia() {
		return this.dia;
	}

	@Override
	public Integer getMes() {
		return this.mes;
	}

	@Override
	public Integer getAnio() {
		return this.anio;
	}

	@Override
	public IFecha getDiaDeHoy() {
		return new Fecha();
	}
	
	@Override
	public Integer restarEnAniosA(IFecha fecha) {
		Integer diferencia = fecha.getAnio() - this.getAnio();
		if (fecha.getMes()<this.getMes()||(this.getMes()==fecha.getMes()&&fecha.getDia()<this.getDia())) {
				diferencia--;
		}
		return diferencia;
	}

}
