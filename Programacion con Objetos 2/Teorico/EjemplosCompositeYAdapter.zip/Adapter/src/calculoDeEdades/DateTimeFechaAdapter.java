package calculoDeEdades;

import org.joda.time.DateTime;
import org.joda.time.Years;

public class DateTimeFechaAdapter implements IFecha {

	private DateTime adaptee;
	
	public DateTimeFechaAdapter(){
		this(new DateTime());
	}
	
	public DateTimeFechaAdapter(DateTime adaptee){
		this.setAdaptee(adaptee);
	}
	
	public DateTimeFechaAdapter(Integer dia, Integer mes, Integer anio){
		this(new DateTime(anio, mes, dia,0,0));
	}
	
	private DateTime getDateTimeFromIfecha(IFecha fecha){
		return new DateTime(fecha.getAnio(), fecha.getMes(), fecha.getDia(),0,0);
	}
	
	@Override
	public Integer getDia() {
		return this.getAdaptee().getDayOfMonth();
	}

	@Override
	public Integer getMes() {
		return this.getAdaptee().getMonthOfYear();
	}

	@Override
	public Integer getAnio() {
		return this.getAdaptee().getYear();
	}

	@Override
	public IFecha getDiaDeHoy() {
		return new DateTimeFechaAdapter();
	}

	@Override
	public Integer restarEnAniosA(IFecha fecha) {
		return Years.yearsBetween(this.getAdaptee(), this.getDateTimeFromIfecha(fecha)).getYears();
	}

	public DateTime getAdaptee() {
		return adaptee;
	}

	public void setAdaptee(DateTime adaptee) {
		this.adaptee = adaptee;
	}

}
