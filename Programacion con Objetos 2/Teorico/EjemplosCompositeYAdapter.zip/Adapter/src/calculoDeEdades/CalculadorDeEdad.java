package calculoDeEdades;

public class CalculadorDeEdad {

	public Integer calcularEdadParaNacimientoEn(IFecha fecha){
		return fecha.restarEnAniosA(fecha.getDiaDeHoy());
	}
}
