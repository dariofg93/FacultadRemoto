package calculoDeEdades;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CalculadorDeEdadTest {

	private CalculadorDeEdad calculador;
	private IFecha fecha;
	private IFecha fechaDateTime;
	
	@Before
	public void setUp(){
		calculador = new CalculadorDeEdad();
		fecha = new Fecha(9, 4, 1982);
		fechaDateTime = new DateTimeFechaAdapter(9,4,1982);
		
	}
	
	
	@Test
	public void test() {
		assertTrue(calculador.calcularEdadParaNacimientoEn(fecha)==32);
		assertTrue(calculador.calcularEdadParaNacimientoEn(fechaDateTime)==32);
	}

}
