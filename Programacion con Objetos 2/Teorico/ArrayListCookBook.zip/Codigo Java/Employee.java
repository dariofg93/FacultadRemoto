package unq.collections;

/**
 * Clase que define un empleado b�sico de una empresa.
 * @author dcano
 *
 */
public class Employee {

	/**
	 * Nombre del Empleado.
	 */
	private String name;

	/**
	 * Apellido del Empleado.
	 */
	private String surname;	

	/**
	 * N�mero de legajo del Empleado.
	 */
	private int number;

	
	/**
	 * Constructor. Crea una instancia de empleado a partir de los 
	 * par�metros recibidos.
	 * 
	 * @param name Nombre del empleado.
	 * @param surname Apellido del empleado.
	 * @param number N�mero de legajo del empleado.
	 */
	public Employee(String name, String surname, int number) {
		this.setName(name);
		this.setSurname(surname);
		this.setNumber(number);
	}

		
	
	/** Getters y Setters */
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}	

}
