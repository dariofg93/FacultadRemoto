package modeloRegistroYequipamiento;

public class Equipamiento {

}
