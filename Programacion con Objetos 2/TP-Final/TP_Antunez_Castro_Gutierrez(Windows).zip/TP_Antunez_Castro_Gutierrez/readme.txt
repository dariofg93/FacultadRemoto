Para importar el proyecto:

1. Abrir la carpeta que se usar� como Workspace en la correci�n del Traba Pr�ctico.

2. Pegar el contenido que se encuentra dentro de la carpeta C�digo(tpObjetos2_Antunez_Castro_Gutierrez).

3. Abrir Eclipse y seleccionar el Workspace que se eligi� en la paso 1.

4. Crear un nuevo proyecto Java con el mismo nombre del proyecto que est� dentro de la carpeta 
C�digo(tpObjetos2_Antunez_Castro_Gutierrez).

5. Agregar los archivos .jars dados(joda-time-2.4.jar y mockito-all-1.9.5.jar).

6. Agregar la libreria jUnit 4. Para hacerlo: 
 * Click derecho en el proyecto -> propiedades -> Java Build Path -> add Library... seleccionar JUnit -> Next -> Finish -> OK