Requerimientos:
* Para ejecutar cualquier programa es necesario tener instalado java.
* Para cualquier SO el procedimiento es similar.

Comentarios:
* En windows es posible tener problemas con las variables de entorno al querer ejecutar el compilador de java...

Antes que nada:
* Descomprimir el archivo y desde una consola, moverse con cd, al directorio del archivo descomprimido.

Ejecucion del Quine:
* Para compilar el archivo:
	javac Quine.java

* Para ejecutarlo:
	java Quine

Ejecucion del Encryptor:
* Se entrega un archivo con la foto de un dinosaurio para probar el programa. Utilizando ese archivo y parado en la direccion de la carpeta, las instrucciones son las siguientes:

* Para compilar el archivo:
	javac Encryptor.java

* Para ejecutar el cifrado del archivo:
	java Encryptor -c fafafa_dino.jpg fafafa.txt

	(
	Se nos pide una contraseña de 32 caracteres que se utilizara al momento de descifrar el archivo. 
	Tales podrian ser:
		* SeguridadEsLaMejorMateriaDeCPIwi
		* AguanteRiverJOJOAguanteRiverJOJO
	)

* Para ejecutar el descifrado del archivo:
	java Encryptor -d fafafa.txt dinofafafa

	(Volvemos a poner la misma clave que antes y listo)